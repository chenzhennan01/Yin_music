export const MUSICNAME = 'Yin-music 后台管理'
