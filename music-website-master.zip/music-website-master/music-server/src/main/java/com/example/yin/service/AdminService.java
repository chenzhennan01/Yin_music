package com.example.yin.service;

public interface AdminService {

    boolean veritypasswd(String name, String password);
}
